<?php
/*
Plugin Name: Multigraph
Plugin URI: http://www.multigraph.org/wordpress-plugin
Description: A plugin that allows Multigraph graphs to be used in WordPress posts
Author: Mark Phillips
Version: 3.3rc1
Author URI: http://www.geomtech.com
*/

/*

This plugin searches all posts for Multigraph markup strings of the form

   [multigraph width=WIDTH height=HEIGHT mugl=MUGLNAME]

and replaces the string with the relevant "<object>...<embed>..."
incantation to create a Multigraph graph in the page at that location.
WIDTH and HEIGHT should be positive integers giving the desired size
of the graph, and MUGLNAME should be the name of an uploaded media
file containing the MUGL for the graph.  The MUGL file must be
uploaded to WordPress separately; it must be present in order for the
graph to display properly, and the title of the uploaded file must be
MUGLNAME.  The file type of the uploaded MUGL file must be "text/xml".

In order for this plugin to work, your WordPress installation will
need to be configured to allow "text/xml" (file suffix ".xml") and
"text/csv" (file suffix ".csv") mime types.

This plugin includes two utility php scripts in addition to the plugin
file itself.

The first one, "mugl.php", is for serving MUGL files.  It returns the
contents of an uploaded media file whose name is given by the value of
the 'file' request parameter.  For example, "mugl.php?file=mymugl.xml"
will return the contents of an uploaded media file whose name is
"mymugl.xml".

The purpose of "mugl.php" is to allow Multigraph markup strings to
refer to a mugl file simply by name, rather than requiring the full
URL to the uploaded file.  So, for example, if you upload a MUGL file
named "mymugl.xml" (be sure to specify "mymugl.xml" as the name of the
uploaded file), the URL of the uploaded file will be someting like
"wp-content/2010/06/mymugl.xml", where "2010" and "06" depend on the
data when you upload the file.  You can create a Multigraph instance
using that MUGL file, however, by simply entering

    [multigraph width=800 height=400 mugl=mymugl.xml]

into a post, without the "wp-content/2010/06/" part.  The Multigraph
plugin will generate a call to "mugl.php" to fetch a mugl file called
"mymugl.xml", and "mugl.php" will take care of finding the actual
location of the file and delivering its contents.

This plugin has a feature that is intended to help combat a problem
that arises when browsers cache MUGL files, thus preventing users from
seeing the correct version of a graph when its MUGL file has been
updated.  In particular, if the 'file' parameter to "mugl.php" ends
with a comma followed by a number, the comma and number are ignored.
When the plugin generates a call to "mugl.php", it appends a comma and
a random number to the 'file' parameter, causing the browser to see it
as a new URL, which in turn insures that Multigraph will correctly
(re)fetch a graph's MUGL file whenever the page containing the graph
is refreshed.

The second utility script included with this plugin is called
"data.php", and it does for CSV data files what "mugl.php" does for
MUGL files, namely delivers the contents of an uploaded file given its
name.  In fact, "data.php" does almost the same thing that "mugl.php"
does.  The one difference is that "mugl.php" takes the additional step
of searching the file contents for any strings of the form

        <csv location="CSVFILE"/>

and replacing CSVFILE with a call to the URL of the data.php script,
passing CSVFILE as the value of the 'file' parameter.  This allows
MUGL that refer to CSV data files by name to continue working
unmodified when uploaded to WordPress, as long as the associated data
file is also uploaded.

*/

function multigraph_edit_tag( $matches )
{
  $assignments = preg_split('/\s+/', trim($matches[1]));
  $args = array();
  for ($i=0; $i<count($assignments); ++$i) {
    $vals = preg_split('/=/', $assignments[$i]);
    $args[$vals[0]] = $vals[1];
  }
  $id     = $args['id'];
  $width  = $args['width'];
  $height = $args['height'];
  $mugl   = $args['mugl'];

  $site_url = get_bloginfo('url');
  $mugl_url = sprintf("%s/wp-content/plugins/multigraph/mugl.php?file=%s,%05d", $site_url, $mugl, rand(10000,99999));
  $swf_url  = sprintf("%s/wp-content/plugins/multigraph/Multigraph-3.3rc1.swf", $site_url);

  return <<<EOS
<object
   id="$id"
   classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"
   width="$width"
   height="$height"
   codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0">
  <param name="quality" value="best" />
  <param name="scale" value="exactfit" />
  <param name="wmode" value="opaque" />
  <param name="bgcolor" value="#ffffff" />
  <param name="src" value="$swf_url" />
  <param name="name" value="$id" />
  <param name="allowfullscreen" value="false" />
  <param name="allowScriptAccess" value="sameDomain" />
  <param name="flashvars" value="muglfile=$mugl_url&amp;swfname=graphdivSwfName">
  <param name="align" value="middle" />
    <embed
        id="$id"
        type="application/x-shockwave-flash"
        width="$width"
        height="$height"
        src="$swf_url"
        name="$id"
        bgcolor="#ffffff"
        wmode="opaque"
        scale="exactfit"
        quality="best"
        allowfullscreen="false"
	allowscriptaccess="sameDomain"
        flashvars="muglfile=$mugl_url&amp;swfname=graphdivSwfName"
        align="middle">
     </embed>
</object>
EOS
    ;
}

function multigraph_filter( $content )
{
  return preg_replace_callback('/\[multigraph\s+([^\]]+)\]/', 'multigraph_edit_tag', $content);
}

add_filter('the_content','multigraph_filter');
