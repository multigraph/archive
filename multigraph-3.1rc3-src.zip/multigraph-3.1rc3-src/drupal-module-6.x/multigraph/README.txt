/* $Id$ */

-- SUMMARY --

  The Multigraph module makes it easy to create Multigraph graphs in a
  Drupal site.  Multigraph (www.multigraph.org) is an open source
  project that makes it possible to create dynamic data graphs in web
  pages.  Multigraph is an Adobe Flash application, but you do not need
  to know anything about Flash to use it.  This module includes a copy
  of Multigraph, so you do not need to download and install a copy of
  Multigraph separately from this module.  Just follow the installation
  instructions below.


-- REQUIREMENTS --

None.


-- INSTALLATION --

* Install as usual: download the module .tar.gz file and unpack it
  into your site's "sites/all/modules" directory.

  The result of this will be the creation of a directory named
  "sites/all/modules/multigraph".  (See http://drupal.org/node/70151
  for further information.)


-- CONFIGURATION --

* Configure user permissions in Administer >> User management >>
  Permissions >> multigraph module

* To give content authors the ability to embed Multigraph graphs in
  posts, visit the Administer >> Site Configuration page and turn on
  the Multigraph filter for one or more input formats.  The simplest
  way to do this is to turn it on for the "Filtered HTML" format, or
  whatever you site's default input format is.
  
-- CREATING AND USING GRAPHS --

* This module defines a new content type, 'Multigraph', which represents
  a Multigraph graph.  To create a new graph, go to Create Content, and
  choose the Multigraph content type.  In the form that appears, enter a
  title for your graph, and a unique tag.  The tag should be a short
  machine-friendly string that uniquely identifies the graph; it should
  consist of just letters and numbers --- no spaces or special
  characters --- and every graph should have its own unique tag.  Also
  enter a width and height for the graph, in pixels, and in the field
  called MUGL, enter the MUGL XML defining your graph; see
  http://www.multigraph.org for an explanation of the MUGL format.  Save
  your entry.
  
* Once your graph entry has been saved, you can embed a copy of it in
  other posts (pages, stories, or any other post type), by entering text
  like the following in the body of the post:
  
      [multigraph tag=TAG width=WIDTH height=HEIGHT]
  
  Be sure to choose an input format that uses the Multigraph filter.


* NOTE ON THE DISTINCTION BETWEEN MULTIGRAPH NODES AND EMBEDDED GRAPHS

  The module stores Multigraph graphs as nodes, just like any other
  piece of content in Drupal.  When you create a new Multigraph graph
  as described above, the system creates a new node of type
  'Multigraph'.  That node is directly visible, just like any other
  node in Drupal, at the URL http://YOURSITE/node/NODE_ID, where
  NODE_ID is the node id.  This is the page that Drupal will display
  when you click "Save" after creating or editing the node.  Drupal
  displays the title of the node at the top, above the graph.

  When you embed a graph in another node, however, using the special
  "[multigraph...]" markup described above, Drupal looks up the
  Multigraph node corresponding to the tag you specify in the markup,
  and inserts that node's graph in the place of the markup.  The graph
  node's title is not included in this case (the containing node's
  title will appear at the top of the post, as usual, though).

  You can embed the same graph in multiple places; each embedding
  creates a reference to the original graph.  If you change the original
  graph, by editing its node, all of the embedded references will change
  as well.

  Each embedded reference can specify its own unique width and height;
  if the width or height is omitted from the "[multigraph...]" markup
  text, the graph's own width and height are used.
