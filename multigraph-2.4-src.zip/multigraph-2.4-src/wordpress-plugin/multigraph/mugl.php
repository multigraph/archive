<?php

//
//  usage:   mugl.php?file=NAME[,RANDOM_NUMBER]
//
//  This script is part of the Multigraph WordPress plugin.  Here is what it does:
//
//      1. takes a single URL parameter named 'file'
//      2. if the value of 'file' ends with a comma followed by a number, the comma and number
//         are stripped off
//      3. searches for an uploaded media file in the WordPress database whose post_title is 'file'
//      4. fetches the contents of the first such file, and modifies it by replacing any occurrence of
//         <cvs location="CSVFILE"/> with a call to the "data.php" script to fetch the given CSVFILE, and then
//      4. returns the possibly modified contents of the file
//

include_once('../../../wp-config.php');
include_once('../../../wp-load.php');
include_once('../../../wp-includes/wp-db.php');

function edit_csv_location( $matches )
{
  $file = trim($matches[1]);

  global $wpdb;
  $query = sprintf("SELECT ID FROM %s WHERE post_title='%s'", $wpdb->posts, $file);
  $num_array = $wpdb->get_col($query, 0) ;
  $post_id = $num_array[0];
  $url = wp_get_attachment_url($post_id);
  return sprintf('<csv location="%s"/>', $url);
}  

// get the 'file' request parameter
$file = $_REQUEST['file'];

// strip off any trailing comma followed by a number (the randomizer part)
$file = preg_replace("/,\d+$/", "", $file);

// look up the path of the file in the wp database
$query = sprintf("SELECT ID FROM %s WHERE post_title='%s'", $wpdb->posts, $file);
$num_array = $wpdb->get_col($query, 0) ;
$mugl_post_id = $num_array[0];
#$mugl_url = wp_get_attachment_url($mugl_post_id);
$mugl_path = get_attached_file($mugl_post_id);

// get its contents
$mugl_contents = file_get_contents($mugl_path);

$siteroot = get_bloginfo('url');
$r = sprintf("%05d", rand(10000,99999));

// return the contents, with the csv location edited
print preg_replace('/<csv\s+location="([^\"]+)"\s*\/>/', 
			    "<csv location=\"$siteroot/wp-content/plugins/multigraph/data.php?file=\$1,$r\"/>",
			    $mugl_contents);
