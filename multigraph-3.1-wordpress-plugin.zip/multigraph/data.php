<?php

//
//  usage:   data.php?file=NAME[,RANDOM_NUMBER]
//
//  This script is part of the Multigraph WordPress plugin.  Here is what it does:
//
//      1. takes a single URL parameter named 'file'
//      2. if the value of 'file' ends with a comma followed by a number, the comma and number
//         are stripped off
//      3. searches for an uploaded media file in the WordPress database whose post_title is 'file'
//      4. returns the contents of the first such file
//

include_once('../../../wp-config.php');
include_once('../../../wp-load.php');
include_once('../../../wp-includes/wp-db.php');

// get the 'file' request parameter
$file = $_REQUEST['file'];

// strip off any trailing comma followed by a number (the randomizer part)
$file = preg_replace("/,\d+$/", "", $file);

// look up the path of the file in the wp database
$query = sprintf("SELECT ID FROM %s WHERE post_title='%s'",
		 mysql_real_escape_string($wpdb->posts),
		 mysql_real_escape_string($file));
$num_array = $wpdb->get_col($query, 0) ;
$post_id = $num_array[0];
$path = get_attached_file($post_id);

// get its contents
$data = file_get_contents($path);

print $data;
